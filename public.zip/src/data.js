const HOME_URL = import.meta.env.VITE_homeURL;
const GetDataUrl = null;

export default HOME_URL;