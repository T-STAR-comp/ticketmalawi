import style from './style.module.css'

function AmlPolicy(){
    return(
        <div className={style.main_cont}>
            <p className={txt}>
                aml polixy
            </p>
        </div>
    )
}